package com.example.imnurse;

import android.app.Application;

import com.firebase.client.Firebase;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Home extends Application {
    public static FirebaseUser firebaseUser;
    public static FirebaseAuth firebaseAuth;
    @Override
    public void onCreate() {
        super.onCreate();

        Firebase.setAndroidContext(this);
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        firebaseAuth = FirebaseAuth.getInstance();
    }
}
