package com.example.imnurse;

import static com.example.imnurse.Home.firebaseAuth;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.iid.FirebaseInstanceId;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {
    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COURSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static boolean locationPermissionGranted = false;
    private GoogleMap mMap;
    // The entry point to the Fused Location Provider.
    private FusedLocationProviderClient mFusedLocationProviderClient;

    LocationRequest locationRequest;
    Location lastLocation;
    private LocationCallback locationCallback;

    //firestore
    FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    DocumentReference nurseDocRef;

    //strings
    String name, Id, authId, email,mobileNumber, password, longitude, latitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        checkLanguage();

        Id = PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("Id", "");
        name = PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("name", "");
        email = PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("email", "");
        password = PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("password", "");
        if (name.equals("") || Id.equals("") || email.equals("") || password.equals("")) {

            startActivity(new Intent(this, WelcomeActivity.class));
            finish();
        }

        setContentView(R.layout.activity_maps);

        Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.app_name);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseSignIn();

        getLocationPermission();
        createLocationRequest();
        // Construct a FusedLocationProviderClient.
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        final SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        Objects.requireNonNull(mapFragment).getMapAsync(this);
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                try {
                    for (Location location : locationResult.getLocations()) {
                        // Update UI with location data
                        // ...
                        lastLocation = location;
                        latitude = String.valueOf(lastLocation.getLatitude());
                        longitude = String.valueOf(lastLocation.getLongitude());
                        Map<String, Object> locationUpdates = new HashMap<>();
                        locationUpdates.put("latitude", latitude);
                        locationUpdates.put("longitude", longitude);
                        LatLng latLng = new LatLng(lastLocation.getLatitude(), lastLocation.getLongitude());
                        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                        mMap.animateCamera(CameraUpdateFactory.zoomTo(16f));

                        nurseDocRef.update(locationUpdates);
//                        nurseReference.child("auth_id").setValue(nurseAuthId);
//                        nurseReference.child("latitude").setValue(location.getLatitude());
//                        nurseReference.child("longitude").setValue(location.getLongitude());
                    }
                } catch (NullPointerException e) {
                    Log.e("location callback", e.getMessage());
                }
            }
        };
//        startLocationUpdates();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mFusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // Add a marker in Sydney and move the camera
//        LatLng sydney = new LatLng(-34, 151);
//        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
//        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        if (locationPermissionGranted) {
            getDeviceLocation();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        locationPermissionGranted = false;
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0) {
                for (int item : grantResults) {
                    if (grantResults[item] != PackageManager.PERMISSION_GRANTED) {
                        return;
                    }
                }
            }
            locationPermissionGranted = true;
            initMap();
        }
    }

    protected void createLocationRequest() {
        locationRequest = LocationRequest.create();
        locationRequest.setInterval(1000);
        locationRequest.setFastestInterval(1000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

//    public void startLocationUpdates(){
//        mFusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
//    }

    public void nurseSignOut() {
        try {
            nurseDocRef.delete().addOnSuccessListener(aVoid -> { }).addOnFailureListener(e ->
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show());
        } catch (Exception ignored) { }
        FirebaseAuth.getInstance().signOut();
    }

    private void firebaseSignIn() {
        email = PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("email", "");
        password = PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("password", "");
        if (email.equals("") || Objects.requireNonNull(password).equals("")) {
            startActivity(new Intent(MapsActivity.this, WelcomeActivity.class));
            finish();
        }
        else {
            firebaseAuth.signInWithEmailAndPassword(
                    Objects.requireNonNull(email), Objects.requireNonNull(password)).addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), R.string.signedInSuccessfully, Toast.LENGTH_LONG).show();
                            String deviceTokenId = FirebaseInstanceId.getInstance().getId();
                            authId = firebaseAuth.getUid();
                            mobileNumber = Objects.requireNonNull(firebaseAuth.getCurrentUser()).getPhoneNumber();
                            Map<String, String> nurseDataMap = new HashMap<>();
                            nurseDataMap.put("name", name);
                            nurseDataMap.put("ID", Id);
                            nurseDataMap.put("mobile", mobileNumber);
                            nurseDataMap.put("auth_id", authId);
                            nurseDataMap.put("device_token", deviceTokenId);
                            nurseDocRef = firebaseFirestore.collection("nurses_available").document(authId);
                            nurseDocRef.set(nurseDataMap);

    //                        databaseReference = FirebaseDatabase.getInstance().getReference().child("nurses available");
    //                        nurseReference = databaseReference.child(nurseAuthId);
    //                        nurseReference.child("nurse_id").setValue(nurseID);
    //                        nurseReference.child("nurse_name").setValue(nurseName);
    //                        requestRefrence = nurseReference.child("device_token").setValue(deviceToken);
    //                        Toast.makeText(MapsActivity.this, R.string.signedInSuccessfully, Toast.LENGTH_LONG).show();
                        }
                    }).addOnFailureListener(e -> {
                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
            });
        }
    }

    private void initMap() {
        SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        Objects.requireNonNull(supportMapFragment).getMapAsync(this);
    }

    private void getDeviceLocation() {
        try {
            if (locationPermissionGranted) {
                final Task location = mFusedLocationProviderClient.getLastLocation();
                location.addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        try {
                            Location currentLocation = (Location) task.getResult();
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()), 12f));
                            mMap.setMyLocationEnabled(true);
                            mMap.getUiSettings().setMapToolbarEnabled(true);
                            //to add mark on current location
//                            mMap.addMarker(new MarkerOptions().position(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude())).title("Marker in Sydney"));
//                                addDataToFirebase(currentLocation);
                        } catch (NullPointerException e) {
                            Toast.makeText(MapsActivity.this, R.string.enable_location, Toast.LENGTH_LONG).show();
                        }
                    } else
                        Toast.makeText(MapsActivity.this, "Unable to get current location", Toast.LENGTH_LONG).show();
                });
            }
        } catch (SecurityException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void getLocationPermission() {
        String[] permissions = {FINE_LOCATION, COURSE_LOCATION};
        if (ContextCompat.checkSelfPermission(getApplicationContext(), FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
            if (ContextCompat.checkSelfPermission(getApplicationContext(), COURSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationPermissionGranted = true;
                initMap();
            } else
                ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);
        else
            ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);
    }

//    private void addDataToFirebase(Location currentLocation) {
//        Map<String, Object> map = new HashMap<>();
//        map.put("name", PreferenceManager.getDefaultSharedPreferences(this).getString("name", null));
//        map.put("ID", PreferenceManager.getDefaultSharedPreferences(this).getString("id", null));
//        map.put("mobile", PreferenceManager.getDefaultSharedPreferences(this).getString("mobile", null));
//        map.put("location", new GeoPoint(currentLocation.getLatitude(), currentLocation.getLongitude()));
//        documentReference.set(map).addOnSuccessListener(new OnSuccessListener<Void>() {
//            @Override
//            public void onSuccess(Void aVoid) {
//                documentReference.update("token ID", documentReference.getId());
//            }
//        }).addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                Log.i(getClass().getName(), "failed to get token ID");
//            }
//        });
//    }

    public void language(String langCode) {
        Resources res = getResources();
        String languageToLoad = langCode;
        Locale locale = new Locale(languageToLoad);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            config.setLayoutDirection(locale);
        }
        res.updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
    }

    public void checkLanguage() {
        String langCode = PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getString("language", "ar");
        if (langCode.equals("ar"))
            language(langCode);
        else
            language("en");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent i;
        switch (item.getItemId()) {
            case R.id.reset_app:
                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
                sharedPreferences.edit().clear().apply();
                startActivity(new Intent(MapsActivity.this, WelcomeActivity.class));
                finish();
                break;
            case R.id.arabic:
                PreferenceManager.getDefaultSharedPreferences(getBaseContext()).edit().putString("language", "ar").apply();
                language("ar");
                i = getBaseContext().getPackageManager().getLaunchIntentForPackage(getBaseContext().getPackageName());
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
                finish();
                break;
            case R.id.english:
                PreferenceManager.getDefaultSharedPreferences(getBaseContext()).edit().putString("language", "en").apply();
                language("en");
                i = getBaseContext().getPackageManager().getLaunchIntentForPackage(getBaseContext().getPackageName());
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onStart() {
        super.onStart();
        checkLanguage();
        if (email == "" || password == "" || name == "" || mobileNumber == "") {
            startActivity(new Intent(MapsActivity.this, WelcomeActivity.class));
            finish();
        }
        else if (firebaseAuth == null) {
            firebaseAuth = FirebaseAuth.getInstance();
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        checkLanguage();
        if (Home.firebaseUser == null) {
            firebaseSignIn();
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            mFusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkLanguage();
        if (Home.firebaseUser == null) {
            firebaseSignIn();
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            mFusedLocationProviderClient.requestLocationUpdates(locationRequest,
                    locationCallback, Looper.getMainLooper());
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        nurseSignOut();
    }
}